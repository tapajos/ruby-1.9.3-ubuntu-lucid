#!/usr/bin/ruby1.9.1
require 'tk'
require 'tkextlib/iwidgets'

Tk::Iwidgets::Extfileselectionbox.new.pack(:padx=>10, :pady=>10,
                                           :fill=>:both, :expand=>true)

Tk.mainloop
